<?php

use Illuminate\Http\Request;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
| Route::middleware('auth:api')->get('/user', function (Request $request) {
|    return $request->user();
| });
*/

/**
 * SIRPORTLY ROUTES
 */
Route::get('/contacts', 'API\ContactController@all');
Route::get('/contacts/{email}', 'API\ContactController@contacts');
Route::get('/contacts/{email}/send-pin', 'API\ContactController@sendPin');

Route::post('/tickets', 'API\TicketController@new');
Route::post('/tickets/update', 'API\TicketController@update');
Route::post('/tickets/add-attachment', 'API\TicketController@add_attachment');
Route::get('/tickets/all', 'API\TicketController@all');
Route::get('/tickets/search', 'API\TicketController@search');
Route::post('/tickets/filter', 'API\TicketController@filter');
Route::get('/tickets/enterprise/all', 'API\CompanyController@all');
Route::get('/tickets/{reference}', 'API\TicketController@ticket');
Route::put('/tickets/resolve', 'API\TicketController@ticket_resolve');
Route::put('/tickets/status-change', 'API\TicketController@ticket_status_change');
Route::get('/tickets/{reference}/attachments/{attachment_id}/{attachment_name}', 'API\TicketController@ticket_attachment');
Route::post('/spql', 'API\TicketController@spql');

Route::get('/departments', 'API\ObjectController@departments');
Route::get('/teams', 'API\ObjectController@teams');
Route::get('/priorities', 'API\ObjectController@priorities');
Route::get('/statuses', 'API\ObjectController@statuses');
Route::get('/filters', 'API\ObjectController@filters');
Route::get('/status', 'API\StatusController@status');
Route::get('/agents', 'API\ObjectController@agents');
Route::get('/articles', 'API\ArticleController@getAll');

Route::get('/crm/record/account/{email}', 'API\CRMRecordController@account');

/**
 * NATIVE ROUTES
 */
Route::resource('provisioning/organizations', 'API\Provisioning\OrganizationController');
Route::resource('provisioning/inventories', 'API\Provisioning\InventoryController');
Route::resource('provisioning/phone-numbers', 'API\Provisioning\PhoneNumberController');
Route::post('provisioning/phone-numbers/bulk-create', 'API\Provisioning\PhoneNumberController@bulkStore');
