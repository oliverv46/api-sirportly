<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Inventory extends Model
{
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'name',
        'slug',
        'approved',
        'organization_id'
    ];

    /**
     * Get the organization that owns the inventory.
     */
    public function organization()
    {
        return $this->belongsTo('App\Models\Organization');
    }

    /**
     * Get the phone numbers for the inventory.
     */
    public function phone_numbers()
    {
        return $this->hasMany('App\Models\PhoneNumber');
    }
}
