<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class PhoneNumber extends Model
{
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'number',
        'caller_id_name',
        'company_name',
        'address_1',
        'address_2',
        'city',
        'state',
        'code',
        'inventory_id',
        'is_active',
        'created_at',
        'updated_at',
    ];

    /**
     * Get the inventory that owns the phone number.
     */
    public function inventory()
    {
        return $this->belongsTo('App\Models\Inventory');
    }
}
