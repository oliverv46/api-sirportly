<?php
namespace App\Http\Controllers\API;
include 'Sirportly/Sirportly.php';

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use App\Http\Controllers\Controller as Controller;
use Sirportly\Sirportly as Sirportly;
use zcrmsdk\crm\setup\restclient\ZCRMRestClient as ZCRMRestClient;
use zcrmsdk\oauth\ZohoOAuth as ZohoOAuth;
use App\Helpers\Helpers;

class BaseController extends Controller {
  public function __construct() {
    /**
     * Add Helpers
     */
    $this->helpers = new Helpers();

    /**
     * Initialize Sirportly
     */
    $this->sirportly = new Sirportly(env('SIRPORTLY_TOKEN'), env('SIRPORTLY_SECRET'));

    /**
     * Initialize ZCRMRestClient
     */
    $configuration = array(
      "client_id"=>env('ZOHO_CLIENT_ID'),
      "client_secret"=>env('ZOHO_SECRET'),
      "redirect_uri"=>env('ZOHO_REDIRECT_URI'),
      "currentUserEmail"=>env('ZOHO_USER_ID'),
      "token_persistence_path" => public_path()
    );
    
    ZCRMRestClient::initialize($configuration);

    // $oAuthClient = ZohoOAuth::getClientInstance();
    // $grantToken = "1000.6c3c56b0278944ff06aa71dc02fd1607.a9729474b2f57104f6143cefa27dc113";
    // $oAuthTokens = $oAuthClient->generateAccessToken($grantToken);

    $this->crm = ZCRMRestClient::getInstance();
  }

  /**
   * success response method.
   *
   * @return \Illuminate\Http\Response
   */

  public function sendResponse($result) {
    return response()->json($result, 200);
  }


  /**
   * return error response.
   *
   * @return \Illuminate\Http\Response
   */
  public function sendError($error, $errorMessages = [], $code = 404) {
    $response = [
      'success' => false,
      'message' => $error,
    ];

    if(!empty($errorMessages)){
      $response['data'] = $errorMessages;
    }

    return response()->json($response, $code);
  }
}
