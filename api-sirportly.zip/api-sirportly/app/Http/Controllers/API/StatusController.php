<?php
namespace App\Http\Controllers\API;

use Illuminate\Http\Request;
use App\Http\Controllers\API\BaseController as BaseController;
use Illuminate\Support\Facades\Storage;

class StatusController extends BaseController {

  /**
   * Status
   */
  public function status() {
    $statuses = json_decode(file_get_contents(public_path('status.json')));
    $names = array(
      'db' => 'Database',
      'lb' => 'Load Balancer',
      'lb' => 'Load Balancer',
      'ms' => 'Media Switch',
      'ms' => 'Media Switch',
      'rm' => 'Reporting Manager',
      'tm' => 'Traffic Manager',
      'tm' => 'Traffic Manager',
      'ts' => 'Traffic Switch',
      'ts' => 'Traffic Switch',
      'ui' => 'Portal Server',
      'wh' => 'Warehouse Server'
    );

    foreach ($statuses as $status) {
      $status->name = $status->name . ' ('. $names[$status->type] .')';
    }

    return $this->sendResponse($statuses);
  }
}
