<?php
namespace App\Http\Controllers\API;

use Illuminate\Http\Request;
use App\Http\Controllers\API\BaseController as BaseController;

class CRMRecordController extends BaseController {

  public function account($email) {
    try {
      $moduleIns = $this->crm->getInstance()->getModuleInstance("Accounts");
      $page = 1;
      $perPage = 200;

      $response = $moduleIns->searchRecords($email, $page, $perPage);
      $records = $response->getData();
      $data = [];

      foreach ($records as $record) {
        array_push($data, $record->getData());
      }

      return $this->sendResponse($data[0]);
    } catch (\Throwable $th) {
      return $this->sendError($th->getMessage(), null, '422');
    }
  }
}
