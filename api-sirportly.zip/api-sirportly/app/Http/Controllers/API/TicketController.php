<?php
namespace App\Http\Controllers\API;

use Illuminate\Http\Request;
use App\Http\Controllers\API\BaseController as BaseController;
use Illuminate\Support\Facades\Storage;

class TicketController extends BaseController {

  /**
   * Get all Tickets from contact
   */
  public function all(Request $request) {
    $params = $request->toArray();
    $response = $this->sirportly->find('tickets/contact', $params);

    return $this->sendResponse($response);
  }

  /**
   * Search Ticket
   */
  public function search(Request $request) {

    $response = $this->sirportly->search($request['query']);
    return $this->sendResponse($response);
  }

  /**
   * Ticket SPQL
   */
  public function spql(Request $request) {

    $response = $this->sirportly->spql($request->toArray());
    return $this->sendResponse($response);
  }

  /**
   * Get Ticket
   */
  public function ticket($reference) {

    $response = $this->sirportly->ticket($reference);
    return $this->sendResponse($response);
  }

  /**
   * Resolve Ticket
   */
  public function ticket_resolve(Request $request) {
    $payload = array(
      'ticket' => $request->ticket['reference'],
      'status' => '8683'
    );

    $response = $this->sirportly->update_ticket($payload);
    return $this->sendResponse($response);
  }

  /**
   * Ticket Status Change
   */
  public function ticket_status_change(Request $request) {
    $payload = $request->toArray();

    $response = $this->sirportly->update_ticket($payload);
    return $this->sendResponse($payload);
  }

  /**
   * Get Attachment
   */
  public function ticket_attachment($reference, $attachment_id, $attachment_name) {
    $params = array(
      'ticket' => $reference,
      'attachment' => $attachment_id
    );

    $response = $this->sirportly->get_attachment($params);
    $content = $response['content'];
    $content_type = $response['info']['content_type'];

    $headers = [
      'Content-type'        => $content_type,
      'Content-Disposition' => 'attachment; filename="'.$attachment_name.'"',
    ];

    return \Response::make($content, 200, $headers);
  }

  /**
   * Post update
   */
  public function update(Request $update) {
    $attachments = '';

    foreach ($update->attachments as $attachment) {
        $attachments .= $attachment['temporary_token'] . ',';
    }

    $payload = array(
      'ticket' => $update->reference,
      'message' => $update->message,
      'contact' => $update->contact['id'],
      'attachments' => $attachments
    );

    $response = $this->sirportly->post_update($payload);
    return $this->sendResponse($response);
  }

  /**
   * Add Attachment
   */
  public function add_attachment(Request $attachment) {
    $data = explode(',', $attachment->file);
    $contents = base64_decode($data[1]);

    Storage::put($attachment->name, $contents);

    $params = array (
      'file' => storage_path('app/' . $attachment->name)
    );

    $response = $this->sirportly->add_attachment($params);

    return $this->sendResponse($response);
  }

  /**
   * Create New Ticket
   */
  public function new (Request $ticket) {
    $props = array (
      'status' => $ticket->status,
      'priority' => $ticket->priority,
      'subject' => $ticket->subject,
      'department' => $ticket->department,
      'contact_method_type' => $ticket->contact_method_type,
      'contact_method_data' => $ticket->contact_method_data,
      'contact_name' => $ticket->contact_name,
      'tag_list' => $ticket->tag_list
    );

    $response = $this->sirportly->create_ticket($props);

    $attachments = '';
    foreach ($ticket->attachments as $attachment) {
        $attachments .= $attachment['temporary_token'] . ',';
    }

    $this->sirportly->post_update(
      array(
        'ticket' => $response['reference'],
        'message' => $ticket->message,
        'contact' => $response['contact']['id'],
        'attachments' => $attachments
      )
    );

    return $this->sendResponse($response);
  }

  /**
   * Get Tickets by Filter
   */
  public function filter(Request $params) {
    $response = $this->sirportly->filter($params->toArray());
    return $this->sendResponse($response);
  }
}
