<?php
namespace App\Http\Controllers\API;

use App\Mail\ContactRequestPin;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;
use App\Http\Controllers\API\BaseController as BaseController;

class ContactController extends BaseController {
  /**
   * Display a listing of the resource.
   *
   * @return \Illuminate\Http\Response
   */

  public function all(Request $request) {
    $response = $this->sirportly->contacts($request->page);
    return $this->sendResponse($response);
  }

  public function contacts($email) {
    $params = array(
      'query' => $email
    );

    $response = $this->sirportly->find('contacts/search', $params);
    return $this->sendResponse($response);
  }

  public function contact_tickets($id) {
    $params = array(
      'contact' => $id
    );

    $response = $this->sirportly->find('tickets/contact', $params);
    return $this->sendResponse($response);
  }

  public function sendPin($email) {
    $params = array(
      'query' => $email
    );

    $contacts = $this->sirportly->find('contacts/search', $params);

    if (count($contacts) > 0) {
      $pin = $contacts[0]['contact']['pin'];
      Mail::to($email)->send(new ContactRequestPin($pin));
      $response = array ('sent' => true);
    } else {
      $response = array ('sent' => false);
    }

    return $this->sendResponse($response);
  }
}
