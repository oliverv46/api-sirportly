<?php
namespace App\Http\Controllers\API;

use Illuminate\Http\Request;
use App\Http\Controllers\API\BaseController as BaseController;

class ObjectController extends BaseController {

  /**
   * Get Departments
   */
  public function departments() {

    $response = $this->sirportly->departments();
    return $this->sendResponse($response);
  }

  /**
   * Get Teams
   */
  public function teams() {

    $response = $this->sirportly->teams();
    return $this->sendResponse($response);
  }

  /**
   * Get Priorities
   */
  public function priorities() {

    $response = $this->sirportly->priorities();
    return $this->sendResponse($response);
  }

  /**
   * Get Statuses
   */
  public function statuses() {

    $response = $this->sirportly->statuses();
    return $this->sendResponse($response);
  }

  /**
   * Get Filters
   */
  public function filters() {

    $response = $this->sirportly->filters();
    return $this->sendResponse($response);
  }

  /**
   * Get agents
   */
  public function agents() {

    $response = $this->sirportly->users();
    return $this->sendResponse($response);
  }
}
