<?php

namespace App\Http\Controllers\API\Provisioning;

use Illuminate\Http\Request;
use App\Http\Controllers\API\BaseController;
use App\Models\Inventory;

class InventoryController extends BaseController {
  /**
   * Display a listing of the resource.
   *
   * @return \Illuminate\Http\Response
   */
  public function index(Request $request) {
    try {
      if ($request->organization_id) {
        $response = Inventory::where('organization_id', '=', $request->organization_id)->orderBy('id', 'desc')->get();
      } else {
        $response = Inventory::orderBy('id', 'desc')->get();
      }

      foreach ($response as $inventory) {
        $inventory['count'] = $inventory->phone_numbers()->count();
      }

      return $this->sendResponse($response);
    } catch (\Throwable $th) {
      return $this->sendError($th->getMessage(), null, '422');
    }
  }

  /**
   * Store a newly created resource in storage.
   *
   * @param  \Illuminate\Http\Request  $request
   * @return \Illuminate\Http\Response
   */
  public function store(Request $request) {
    try {
      $validatedData = $request->validate([
        'name' => 'required',
        'organization_id' => 'required'
      ]);

      $inventory = new Inventory;
      $inventory->name = $request->name;
      $inventory->approved = $request->approved;
      $inventory->organization_id = $request->organization_id;
      $inventory->slug = $this->helpers->slugify($request->name);
      $inventory->progress_status = $request->progress_status;
      $inventory->progress_status_description = $request->progress_status_description;

      return $this->sendResponse($inventory->save());
    } catch (\Throwable $th) {
      return $this->sendError($th->getMessage(), null, '422');
    }
  }

  /**
   * Display the specified resource.
   *
   * @param  int  $id
   * @return \Illuminate\Http\Response
   */
  public function show($id) {
    try {
      $response = Inventory::findOrFail($id);
      return $this->sendResponse($response);
    } catch (\Throwable $th) {
      return $this->sendError($th->getMessage(), null, '422');
    }
  }

  /**
   * Update the specified resource in storage.
   *
   * @param  \Illuminate\Http\Request  $request
   * @param  int  $id
   * @return \Illuminate\Http\Response
   */
  public function update(Request $request, $id) {
    try {
      $inventory = Inventory::findOrFail($id);

      $inventory->name = $request->name;
      $inventory->approved = $request->approved;
      $inventory->organization_id = $request->organization_id;
      $slug = $request->slug ? $request->slug : $request->name;
      $inventory->slug = $this->helpers->slugify($slug);
      $inventory->progress_status = $request->progress_status;
      $inventory->progress_status_description = $request->progress_status_description;

      return $this->sendResponse($inventory->save());
    } catch (\Throwable $th) {
      return $this->sendError($th->getMessage(), null, '422');
    }
  }

  /**
   * Remove the specified resource from storage.
   *
   * @param  int  $id
   * @return \Illuminate\Http\Response
   */
  public function destroy($id) {
    try {
      $inventory = Inventory::findOrFail($id);
      return $this->sendResponse($inventory->delete());
    } catch (\Throwable $th) {
      return $this->sendError($th->getMessage(), null, '422');
    }
  }
}
