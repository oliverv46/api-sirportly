<?php

namespace App\Http\Controllers\API\Provisioning;

use Illuminate\Http\Request;
use App\Http\Controllers\API\BaseController;
use App\Models\PhoneNumber;
use Carbon\Carbon;

class PhoneNumberController extends BaseController {
  /**
   * Display a listing of the resource.
   *
   * @return \Illuminate\Http\Response
   */
  public function index(Request $request) {
    try {
      if ($request->inventory_id) {
        $response = PhoneNumber::where('inventory_id', '=', $request->inventory_id)->orderBy('id', 'asc')->get();
      } else {
        $response = PhoneNumber::orderBy('id', 'desc')->get();
      }

      return $this->sendResponse($response);
    } catch (\Throwable $th) {
      return $this->sendError($th->getMessage(), null, '422');
    }
  }

  /**
   * Store a newly created resource in storage.
   *
   * @param  \Illuminate\Http\Request  $request
   * @return \Illuminate\Http\Response
   */
  public function store(Request $request) {
    try {
      $validatedData = $request->validate([
        'number' => 'required',
        'caller_id_name' => 'required',
        'company_name' => 'required',
        'address_1' => 'required',
        'city' => 'required',
        'state' => 'required',
        'code' => 'required',
        'inventory_id' => 'required'
      ]);

      $phone_number = new PhoneNumber;

      $phone_number->number = $request->number;
      $phone_number->caller_id_name = $request->caller_id_name;
      $phone_number->company_name = $request->company_name;
      $phone_number->address_1 = $request->address_1;
      $phone_number->address_2 = $request->address_2;
      $phone_number->city = $request->city;
      $phone_number->state = $request->state;
      $phone_number->code = $request->code;
      $phone_number->inventory_id = $request->inventory_id;

      return $this->sendResponse($phone_number->save());
    } catch (\Throwable $th) {
      return $this->sendError($th->getMessage(), null, '422');
    }
  }

  /**
   * [BULK] Store a newly created resource in storage.
   *
   * @param  \Illuminate\Http\Request  $request
   * @return \Illuminate\Http\Response
   */
  public function bulkStore(Request $request) {
    try {
      $data = $request->toArray();
      $now = Carbon::now('utc')->toDateTimeString();
      $phoneNumbers = array();

      foreach ($data as $phoneNumber) {
        $count = PhoneNumber::where('number', '=', $phoneNumber['number'])->count();
        if ($count == 0) {
          $phoneNumber['created_at'] = $now;
          $phoneNumber['updated_at'] = $now;
          array_push($phoneNumbers, $phoneNumber);
        }
      }

      return $this->sendResponse(PhoneNumber::insert($phoneNumbers));
    } catch (\Throwable $th) {
      return $this->sendError($th->getMessage(), null, '422');
    }
  }

  /**
   * Display the specified resource.
   *
   * @param  int  $id
   * @return \Illuminate\Http\Response
   */
  public function show($id) {
    try {
      $response = PhoneNumber::findOrFail($id);
      return $this->sendResponse($response);
    } catch (\Throwable $th) {
      return $this->sendError($th->getMessage(), null, '422');
    }
  }

  /**
   * Update the specified resource in storage.
   *
   * @param  \Illuminate\Http\Request  $request
   * @param  int  $id
   * @return \Illuminate\Http\Response
   */
  public function update(Request $request, $id) {
    try {
      $phone_number = PhoneNumber::findOrFail($id);

      $phone_number->number = $request->number;
      $phone_number->caller_id_name = $request->caller_id_name;
      $phone_number->company_name = $request->company_name;
      $phone_number->address_1 = $request->address_1;
      $phone_number->address_2 = $request->address_2;
      $phone_number->city = $request->city;
      $phone_number->state = $request->state;
      $phone_number->code = $request->code;
      $phone_number->inventory_id = $request->inventory_id;
      $phone_number->is_active = $request->is_active;

      return $this->sendResponse($phone_number->save());
    } catch (\Throwable $th) {
      return $this->sendError($th->getMessage(), null, '422');
    }
  }

  /**
   * Remove the specified resource from storage.
   *
   * @param  int  $id
   * @return \Illuminate\Http\Response
   */
  public function destroy($id) {
    try {
      $phone_number = PhoneNumber::findOrFail($id);
      return $this->sendResponse($phone_number->delete());
    } catch (\Throwable $th) {
      return $this->sendError($th->getMessage(), null, '422');
    }
  }
}
