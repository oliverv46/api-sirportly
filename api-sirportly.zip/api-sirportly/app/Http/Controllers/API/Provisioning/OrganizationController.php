<?php

namespace App\Http\Controllers\API\Provisioning;

use Illuminate\Http\Request;
use App\Http\Controllers\API\BaseController;
use App\Models\Organization;

class OrganizationController extends BaseController {
  /**
   * Display a listing of the resource.
   *
   * @return \Illuminate\Http\Response
   */
  public function index() {
    try {
      $response = Organization::orderBy('id', 'desc')->get();
      return $this->sendResponse($response);
    } catch (\Throwable $th) {
      return $this->sendError($th->getMessage(), null, '422');
    }
  }

  /**
   * Store a newly created resource in storage.
   *
   * @param  \Illuminate\Http\Request  $request
   * @return \Illuminate\Http\Response
   */
  public function store(Request $request) {
    try {
      $validatedData = $request->validate([
        'name' => 'required'
      ]);

      $organization = new Organization;
      $organization->name = $request->name;
      $organization->slug = $this->helpers->slugify($request->name);

      return $this->sendResponse($organization->save());
    } catch (\Throwable $th) {
      return $this->sendError($th->getMessage(), null, '422');
    }
  }

  /**
   * Display the specified resource.
   *
   * @param  int  $id
   * @return \Illuminate\Http\Response
   */
  public function show($id) {
    try {
      $response = Organization::findOrFail($id);
      return $this->sendResponse($response);
    } catch (\Throwable $th) {
      return $this->sendError($th->getMessage(), null, '422');
    }
  }

  /**
   * Update the specified resource in storage.
   *
   * @param  \Illuminate\Http\Request  $request
   * @param  int  $id
   * @return \Illuminate\Http\Response
   */
  public function update(Request $request, $id) {
    try {
      $organization = Organization::findOrFail($id);

      $organization->name = $request->name;
      $slug = $request->slug ? $request->slug : $request->name;
      $organization->slug = $this->helpers->slugify($slug);

      return $this->sendResponse($organization->save());
    } catch (\Throwable $th) {
      return $this->sendError($th->getMessage(), null, '422');
    }
  }

  /**
   * Remove the specified resource from storage.
   *
   * @param  int  $id
   * @return \Illuminate\Http\Response
   */
  public function destroy($id) {
    try {
      $organization = Organization::findOrFail($id);
      return $this->sendResponse($organization->delete());
    } catch (\Throwable $th) {
      return $this->sendError($th->getMessage(), null, '422');
    }
  }
}
