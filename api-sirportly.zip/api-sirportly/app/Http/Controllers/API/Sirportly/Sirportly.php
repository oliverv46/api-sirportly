<?php

namespace Sirportly;
use Exception;
use CURLFile;

/**
* Sirportly PHP API Library
* @see https://github.com/sirportly/php-library
* @version  1.0
*/
class Sirportly
{
  private $token;
  private $secret;
  private $url;

  public function __construct($token,$secret,$url='https://api.sirportly.com/api/v2/') {
    $this->token  = $token;
    $this->secret = $secret;
    $this->url    = $url;
  }

    /**
     * @param $action
     * @param array $postfields
     * @return mixed
    //  * @throws SirportlyDefaultException
     */
  private function query($method, $postfields=array(), $decode=TRUE) {
    $default_params = [];
    $url = $this->url . $method;
    
    if (array_key_exists('file', $postfields)) {
      $postfields = array_merge(
        $default_params,
        array('file' => new CURLFile($postfields['file']))
      );
    } else {
      $postfields = array_merge($default_params, $postfields);
    }

    
    $header = array(
      'X-Auth-Token: '.$this->token,
      'X-Auth-Secret: '.$this->secret
    );

    $curl = curl_init();
    curl_setopt($curl, CURLOPT_URL, $url);
    curl_setopt($curl, CURLOPT_POST, TRUE);
    curl_setopt($curl, CURLOPT_POSTFIELDS, $postfields);
    curl_setopt($curl, CURLOPT_HTTPHEADER, $header);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);

    $result = curl_exec($curl);
    $info = curl_getinfo($curl);

    if ($result === false || !in_array($info['http_code'], [200, 201])) {
        $error = "No cURL data returned for $url [http error: ". $info['http_code']. "]";
        if (curl_error($curl)) {
            $error .= "\n" . curl_error($curl);
        }
        throw new Exception($error);
    }

    curl_close($curl);

    if ($decode) {
      $result = json_decode($result,true);
    } else {
      $result = array('content' => $result, 'info' => $info);
    }

    return $result;
  }

  public function find($endpoint, $params) {
    return $this->query($endpoint, $params);
  }

  public function filter($params) {
    return $this->query('tickets/filter', $params);
  }

  public function search($search) {
    return $this->query('tickets/search', array('query' => $search));
  }

  public function ticket($ticket_reference) {
    return $this->query('tickets/ticket', array('ticket' => $ticket_reference));
  }

  public function create_ticket($params = array()) {
    return $this->query('tickets/submit',$params);
  }

  public function post_update($params = array()) {
    return $this->query('tickets/post_update',$params);
  }

  public function tickets($page = '1') {
    return $this->query('tickets/all',array('page' => $page));
  }

  public function update_ticket($params = array()) {
    return $this->query('tickets/update',$params);
  }

  public function add_attachment($params = array()) {
    return $this->query('tickets/add_attachment',$params);
  }

  public function get_attachment($params = array()) {
    return $this->query('tickets/attachment',$params, FALSE);
  }

  public function run_macro($params = array()) {
    return $this->query('tickets/macro',$params);
  }

  public function add_follow_up($params = array()) {
    return $this->query('tickets/add_followup',$params);
  }

  public function create_user($params = array()) {
    return $this->query('users/create',$params);
  }

  public function statuses() {
    return $this->query('objects/statuses');
  }

  public function priorities() {
    return $this->query('objects/priorities');
  }

  public function teams() {
    return $this->query('objects/teams');
  }

  public function brands() {
    return $this->query('objects/brands');
  }

  public function departments() {
    return $this->query('objects/departments');
  }

  public function escalation_paths() {
    return $this->query('objects/escalation_paths');
  }

  public function slas() {
    return $this->query('objects/slas');
  }

  public function filters() {
    return $this->query('objects/filters');
  }

  public function spql($params = array()) {
    return $this->query('tickets/spql',$params);
  }

  /**
  * Fetch a list of knowledgebases from your account
  * @return array list of knowledgebases in an array format.
  */
  public function kb_list() {
    return $this->query('knowledge/list');
  }

  /**
  * Return a single knowledgebase tree.
  * @param  int $kb_id The ID of the knowledgebase you want to load
  * @return array        The knowledgebase as an array.
  */
  public function kb($kb_id) {
    return $this->query('knowledge/tree', array('kb' => $kb_id));
  }

  /**
  * Fetch a list of users from your account
  * @return array        The users as an array.
  */
  public function users($page=1) {
    return $this->query('users/all', array('page' => $page));
  }

  /**
  * Fetch a list of contacts from your account
  * @return array        The contacts as an array.
  */
  public function contacts($page=1) {
    return $this->query('contacts/all', array('page' => $page));
  }

  /**
   * Articles
   */
  public function articles($params = array()) {
    return $this->query('support_centres/articles',$params);
  }
}
?>
