<?php
namespace App\Helpers;
use Cocur\Slugify\Slugify;

class Helpers {
	public function slugify ($string) {
		$slugify = new Slugify();
		return $slugify->slugify($string);
	}
}
